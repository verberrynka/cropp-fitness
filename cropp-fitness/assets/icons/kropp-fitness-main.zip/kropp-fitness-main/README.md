# kropp-fitness
Адаптивная верстка сайта по макету для [YouTube-канала](https://www.youtube.com/@AleksanderLamkov)

[Плейлист](https://youtube.com/playlist?list=PL0MUAHwery4rqkzKF1mDBCIH_eZgjY6uN&si=3Uqb7trqQUIL25LB)
